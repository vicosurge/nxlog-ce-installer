/* Automatically generated from pm_buffer-api.xml by codegen.pl */
#ifndef __NX_EXPR_FUNCPROC_pm_buffer_H
#define __NX_EXPR_FUNCPROC_pm_buffer_H

#include "../../../common/expr.h"
#include "../../../common/module.h"


/* FUNCTIONS */

#define nx_api_declarations_pm_buffer_func_num 2
void nx_expr_func__pm_buffer_buffer_size(nx_expr_eval_ctx_t *eval_ctx, nx_module_t *module, nx_value_t *retval, int32_t num_arg, nx_value_t *args);
void nx_expr_func__pm_buffer_buffer_count(nx_expr_eval_ctx_t *eval_ctx, nx_module_t *module, nx_value_t *retval, int32_t num_arg, nx_value_t *args);
#define nx_api_declarations_pm_buffer_proc_num 0


#endif /* __NX_EXPR_FUNCPROC_pm_buffer_H */
