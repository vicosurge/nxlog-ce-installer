use lib 'c:\Strawberry\perl\lib';
use lib 'c:\Strawberry\perl\vendor\lib';
use lib 'c:\Strawberry\perl\site\lib';
use lib 'c:\Program Files\nxlog\data';